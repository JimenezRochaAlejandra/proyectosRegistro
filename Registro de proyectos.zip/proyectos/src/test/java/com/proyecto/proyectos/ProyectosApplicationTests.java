package com.proyecto.proyectos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectosApplicationTests {

	@Test
	void contextLoads() {
	}

}
